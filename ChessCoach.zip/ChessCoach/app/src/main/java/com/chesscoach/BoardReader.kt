package com.chesscoach

import java.nio.ByteBuffer

class Circle(val cx: Float, val cy: Float, val r: Float, val color: Int, val alpha: Float)

class Frame(
    private val buf: ByteBuffer,
    val w: Int,
    val h: Int,
    private val rowStride: Int,
    private val pixStride: Int
) {
    fun rgb(x: Int, y: Int): Int {
        val xx = if (x < 0) 0 else if (x >= w) w - 1 else x
        val yy = if (y < 0) 0 else if (y >= h) h - 1 else y
        val o = yy * rowStride + xx * pixStride
        val r = buf.get(o).toInt() and 0xFF
        val g = buf.get(o + 1).toInt() and 0xFF
        val b = buf.get(o + 2).toInt() and 0xFF
        return (r shl 16) or (g shl 8) or b
    }
}

class Templates(val shapes: Array<List<BooleanArray>>, val lumThr: Float)

class ParseResult(val board: IntArray, val uncertain: BooleanArray, val ok: Boolean)

/**
 * Board codes (index = rank*8 + file, rank 0 = chess rank 1):
 * 0 empty; white +1..+6, black -1..-6 for P N B R Q K.
 */
class BoardReader {
    companion object {
        const val G = 24
        const val N = G * G
        const val DIFF_T = 80

        private fun buildCorner(): IntArray {
            val ids = intArrayOf(0, 1, 2, G - 3, G - 2, G - 1)
            val out = IntArray(ids.size * ids.size)
            var k = 0
            for (j in ids) for (i in ids) {
                out[k++] = j * G + i
            }
            return out
        }

        val CORNER: IntArray = buildCorner()

        fun toSq(r: Int, c: Int, userWhite: Boolean): Int =
            if (userWhite) (7 - r) * 8 + c else r * 8 + (7 - c)

        fun screenRow(sq: Int, userWhite: Boolean): Int =
            if (userWhite) 7 - sq / 8 else sq / 8

        fun screenCol(sq: Int, userWhite: Boolean): Int =
            if (userWhite) sq % 8 else 7 - sq % 8

        // type index: P0 N1 B2 R3 Q4 K5
        private val BACK = intArrayOf(3, 1, 2, 4, 5, 2, 1, 3)

        fun initialBoard(): IntArray {
            val b = IntArray(64)
            for (f in 0..7) {
                b[f] = BACK[f] + 1
                b[8 + f] = 1
                b[48 + f] = -1
                b[56 + f] = -(BACK[f] + 1)
            }
            return b
        }

        fun encode(t: Templates): String {
            val sb = StringBuilder()
            sb.append(t.lumThr.toString()).append('|')
            for (k in 0..5) {
                for ((idx, m) in t.shapes[k].withIndex()) {
                    if (idx > 0) sb.append(',')
                    for (b in m) sb.append(if (b) '1' else '0')
                }
                if (k < 5) sb.append(';')
            }
            return sb.toString()
        }

        fun decode(s: String): Templates? {
            try {
                val parts = s.split('|')
                if (parts.size != 2) return null
                val thr = parts[0].toFloat()
                val types = parts[1].split(';')
                if (types.size != 6) return null
                val shapes = Array<List<BooleanArray>>(6) { k ->
                    types[k].split(',').filter { it.length == N }.map { str ->
                        BooleanArray(N) { idx -> str[idx] == '1' }
                    }
                }
                for (l in shapes) if (l.isEmpty()) return null
                return Templates(shapes, thr)
            } catch (e: Exception) {
                return null
            }
        }
    }

    private class Sq {
        val mask = BooleanArray(N)
        var occ = false
        var mass = 0
        var lum = 0f
    }

    // indexed by screen square r*8+c
    private val px = Array(64) { IntArray(N) }
    private val sqs = Array(64) { Sq() }
    private val hr = IntArray(256)
    private val hg = IntArray(256)
    private val hb = IntArray(256)

    private fun median(h: IntArray, n: Int): Int {
        var acc = 0
        for (i in 0..255) {
            acc += h[i]
            if (acc * 2 >= n) return i
        }
        return 255
    }

    /** 1 = white pieces at bottom, -1 = black at bottom, 0 = not a start-like position. */
    fun detectColor(): Int {
        var top = 0f
        var tn = 0
        var bot = 0f
        var bn = 0
        for (r in 0..7) {
            for (c in 0..7) {
                val s = sqs[r * 8 + c]
                if (r in 2..5) {
                    if (s.occ) return 0
                } else if (s.occ) {
                    if (r <= 1) {
                        top += s.lum
                        tn++
                    } else {
                        bot += s.lum
                        bn++
                    }
                }
            }
        }
        if (tn < 14 || bn < 14) return 0
        val d = bot / bn - top / tn
        return if (d > 40f) 1 else if (d < -40f) -1 else 0
    }

    fun debug(): String {
        val sb = StringBuilder()
        var top = 0f
        var tn = 0
        var bot = 0f
        var bn = 0
        for (r in 0..7) {
            var cnt = 0
            for (c in 0..7) {
                val s = sqs[r * 8 + c]
                if (s.occ) {
                    cnt++
                    if (r <= 1) {
                        top += s.lum
                        tn++
                    } else if (r >= 6) {
                        bot += s.lum
                        bn++
                    }
                }
            }
            sb.append(cnt).append(' ')
        }
        sb.append(" | lum ")
        sb.append(if (tn > 0) (top / tn).toInt() else -1)
        sb.append("/")
        sb.append(if (bn > 0) (bot / bn).toInt() else -1)
        return sb.toString()
    }

    fun load(f: Frame, left: Float, top: Float, right: Float, bottom: Float, circles: List<Circle>) {
        val sw = (right - left) / 8f
        val sh = (bottom - top) / 8f
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val arr = px[r * 8 + c]
                val x0 = left + c * sw
                val y0 = top + r * sh
                for (j in 0 until G) {
                    val y = y0 + (j + 0.5f) / G * sh
                    val yi = y.toInt()
                    for (i in 0 until G) {
                        val x = x0 + (i + 0.5f) / G * sw
                        var v = f.rgb(x.toInt(), yi)
                        if (circles.isNotEmpty()) v = unblend(v, x, y, circles)
                        arr[j * G + i] = v
                    }
                }
                analyze(arr, sqs[r * 8 + c])
            }
        }
        if (net != null) classifyAll(f, left, top, right, bottom)
    }

    // ---------- neural network square reader ----------
    var net: PieceNet? = null
    private val aiFeat = Array(64) { FloatArray(1200) }
    private val aiHave = BooleanArray(64)
    private val aiBuf = FloatArray(1200)
    val aiClass = IntArray(64)
    val aiConf = FloatArray(64)

    private fun classifyAll(f: Frame, left: Float, top: Float, right: Float, bottom: Float) {
        val n = net ?: return
        val sw = (right - left) / 8f
        val sh = (bottom - top) / 8f
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val k = r * 8 + c
                val x0 = left + c * sw
                val y0 = top + r * sh
                for (j in 0 until 20) {
                    for (i in 0 until 20) {
                        var sr = 0
                        var sg = 0
                        var sb = 0
                        for (dj in 0..1) {
                            val y = (y0 + ((j * 2 + dj + 0.5f) / 40f) * sh).toInt()
                            for (di in 0..1) {
                                val x = (x0 + ((i * 2 + di + 0.5f) / 40f) * sw).toInt()
                                val v = f.rgb(x, y)
                                sr += (v shr 16) and 255
                                sg += (v shr 8) and 255
                                sb += v and 255
                            }
                        }
                        val o = (j * 20 + i) * 3
                        aiBuf[o] = sr / 4f / 255f - 0.5f
                        aiBuf[o + 1] = sg / 4f / 255f - 0.5f
                        aiBuf[o + 2] = sb / 4f / 255f - 0.5f
                    }
                }
                var same = aiHave[k]
                if (same) {
                    var d = 0f
                    val old = aiFeat[k]
                    for (t in 0 until 1200) d += Math.abs(aiBuf[t] - old[t])
                    if (d / 1200f > 0.005f) same = false
                }
                if (!same) {
                    System.arraycopy(aiBuf, 0, aiFeat[k], 0, 1200)
                    val pr = n.forward(aiBuf)
                    var bi = 0
                    for (t in 1 until pr.size) if (pr[t] > pr[bi]) bi = t
                    aiClass[k] = bi
                    aiConf[k] = pr[bi]
                    aiHave[k] = true
                }
            }
        }
    }

    private fun aiToCode(cls: Int): Int = if (cls == 0) 0 else if (cls <= 6) cls else -(cls - 6)

    /** Colour grid (0 / 1 white / -1 black) from the network. Unsure squares keep the expected value. */
    fun aiGrid(userWhite: Boolean, expected: IntArray?, ignore: IntArray?): IntArray {
        val g = IntArray(64)
        for (r in 0..7) {
            for (c in 0..7) {
                val sq = toSq(r, c, userWhite)
                val k = r * 8 + c
                if (expected != null && ((ignore != null && ignore.contains(sq)) || aiConf[k] < 0.5f)) {
                    g[sq] = expected[sq]
                    continue
                }
                val cls = aiClass[k]
                g[sq] = if (cls == 0) 0 else if (cls <= 6) 1 else -1
            }
        }
        return g
    }

    /** Full board (piece codes) from the network, or null if any square is unsure. */
    fun aiBoard(userWhite: Boolean, minConf: Float): IntArray? {
        val b = IntArray(64)
        for (r in 0..7) {
            for (c in 0..7) {
                val k = r * 8 + c
                if (!aiHave[k] || aiConf[k] < minConf) return null
                b[toSq(r, c, userWhite)] = aiToCode(aiClass[k])
            }
        }
        return b
    }

    /** Piece code on a chess square if the network is confident, else 0. */
    fun aiCodeAt(userWhite: Boolean, sq: Int): Int {
        val k = screenRow(sq, userWhite) * 8 + screenCol(sq, userWhite)
        if (!aiHave[k] || aiConf[k] < 0.85f) return 0
        return aiToCode(aiClass[k])
    }

    /** 1 = white at the bottom, -1 = black at the bottom, 0 = not a clean start-like picture. */
    fun aiOrientation(): Int {
        var wb = 0
        var bb = 0
        var wt = 0
        var bt = 0
        for (r in 0..7) {
            for (c in 0..7) {
                val k = r * 8 + c
                if (!aiHave[k] || aiConf[k] < 0.6f) return 0
                val cls = aiClass[k]
                if (r in 2..5) {
                    if (cls != 0) return 0
                } else {
                    if (cls == 0) return 0
                    val white = cls <= 6
                    if (r >= 6) {
                        if (white) wb++ else bb++
                    } else {
                        if (white) wt++ else bt++
                    }
                }
            }
        }
        return if (wb == 16 && bt == 16) 1 else if (bb == 16 && wt == 16) -1 else 0
    }

    private fun clamp(v: Float): Int {
        val i = Math.round(v)
        return if (i < 0) 0 else if (i > 255) 255 else i
    }

    private fun unblend(v: Int, x: Float, y: Float, circles: List<Circle>): Int {
        for (c in circles) {
            val dx = x - c.cx
            val dy = y - c.cy
            val d = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            if (d <= c.r - 1.5f) {
                val a = c.alpha
                val cr = (c.color shr 16) and 255
                val cg = (c.color shr 8) and 255
                val cb = c.color and 255
                val r = clamp((((v shr 16) and 255) - cr * a) / (1f - a))
                val g = clamp((((v shr 8) and 255) - cg * a) / (1f - a))
                val b = clamp(((v and 255) - cb * a) / (1f - a))
                return (r shl 16) or (g shl 8) or b
            } else if (d <= c.r + 1.5f) {
                return -1
            }
        }
        return v
    }

    private fun analyze(arr: IntArray, s: Sq) {
        java.util.Arrays.fill(s.mask, false)
        s.occ = false
        s.mass = 0
        s.lum = 0f
        java.util.Arrays.fill(hr, 0)
        java.util.Arrays.fill(hg, 0)
        java.util.Arrays.fill(hb, 0)
        var n = 0
        for (k in 0 until N) {
            val v = arr[k]
            if (v < 0) continue
            hr[(v shr 16) and 255]++
            hg[(v shr 8) and 255]++
            hb[v and 255]++
            n++
        }
        if (n < 100) return
        val br = median(hr, n)
        val bg = median(hg, n)
        val bb = median(hb, n)
        val sb0 = (br + bg + bb + 1).toFloat()
        val nr = br / sb0
        val ng = bg / sb0
        val nb = bb / sb0
        for (k in 0 until N) {
            val v = arr[k]
            if (v < 0) continue
            val r = (v shr 16) and 255
            val g = (v shr 8) and 255
            val b = v and 255
            val d = Math.abs(r - br) + Math.abs(g - bg) + Math.abs(b - bb)
            if (d > 35) {
                // wood shadows/highlights keep the wood's colour ratio; pieces (grey) do not
                val sp = (r + g + b + 1).toFloat()
                val chroma = Math.abs(r / sp - nr) + Math.abs(g / sp - ng) + Math.abs(b / sp - nb)
                if (chroma > 0.05f || d > 110) {
                    val ci = k % G
                    val cj = k / G
                    if (ci >= 2 && ci < G - 2 && cj >= 2 && cj < G - 2) s.mask[k] = true
                }
            }
        }
        fillGaps(s.mask)
        val mass = keepLargest(s.mask)
        s.mass = mass
        var minX = G
        var maxX = -1
        var minY = G
        var maxY = -1
        for (k in 0 until N) {
            if (s.mask[k]) {
                val x = k % G
                val y = k / G
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        // a real piece is a big, tall blob; wood-grain streaks / knots are small or thin
        s.occ = mass >= 40 && (maxY - minY + 1) >= 10 && (maxX - minX + 1) >= 9
        java.util.Arrays.fill(hl, 0)
        var cnt = 0
        for (k in 0 until N) {
            if (!s.mask[k]) continue
            val v = arr[k]
            val r = (v shr 16) and 255
            val g = (v shr 8) and 255
            val b = v and 255
            hl[(r * 299 + g * 587 + b * 114) / 1000]++
            cnt++
        }
        // median luminance of the piece pixels (robust against stray wood pixels)
        var lm = 0
        if (cnt > 0) {
            var acc = 0
            for (i in 0..255) {
                acc += hl[i]
                if (acc * 2 >= cnt) {
                    lm = i
                    break
                }
            }
        }
        s.lum = lm.toFloat()
    }

    private val hl = IntArray(256)
    private val lab = IntArray(N)
    private val stack = IntArray(N)

    /** Keeps only the biggest connected blob (the piece); removes wood-grain noise. */
    private fun keepLargest(m: BooleanArray): Int {
        java.util.Arrays.fill(lab, 0)
        var best = 0
        var bestId = 0
        var id = 0
        for (s0 in 0 until N) {
            if (!m[s0] || lab[s0] != 0) continue
            id++
            var sp = 0
            stack[sp++] = s0
            lab[s0] = id
            var size = 0
            while (sp > 0) {
                val p = stack[--sp]
                size++
                val x = p % G
                val y = p / G
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
                        val nx = x + dx
                        val ny = y + dy
                        if (nx < 0 || ny < 0 || nx >= G || ny >= G) continue
                        val q = ny * G + nx
                        if (m[q] && lab[q] == 0) {
                            lab[q] = id
                            stack[sp++] = q
                        }
                    }
                }
            }
            if (size > best) {
                best = size
                bestId = id
            }
        }
        for (k in 0 until N) if (m[k] && lab[k] != bestId) m[k] = false
        return best
    }

    // ---------- automatic grid alignment (start position, rows 3-6 empty) ----------
    private fun lumAt(f: Frame, x: Int, y: Int): Int {
        val v = f.rgb(x, y)
        return (((v shr 16) and 255) * 299 + ((v shr 8) and 255) * 587 + (v and 255) * 114) / 1000
    }

    private fun scoreV(f: Frame, l: Float, r: Float, t: Float, b: Float): Float {
        val w = (r - l) / 8f
        val h = (b - t) / 8f
        var sum = 0f
        var n = 0
        for (i in 1..7) {
            val x = l + i * w
            val xa = (x - 8f).toInt()
            val xb = (x - 3f).toInt()
            val xc = (x + 3f).toInt()
            val xd = (x + 8f).toInt()
            for (row in 2..5) {
                for (k in 0 until 6) {
                    val y = (t + row * h + (0.2f + 0.6f * (k + 0.5f) / 6f) * h).toInt()
                    var a = 0
                    for (xx in xa..xb) a += lumAt(f, xx, y)
                    var c = 0
                    for (xx in xc..xd) c += lumAt(f, xx, y)
                    sum += Math.abs(a / (xb - xa + 1f) - c / (xd - xc + 1f))
                    n++
                }
            }
        }
        return sum / n
    }

    private fun scoreH(f: Frame, l: Float, r: Float, t: Float, b: Float): Float {
        val w = (r - l) / 8f
        val h = (b - t) / 8f
        var sum = 0f
        var n = 0
        for (j in 3..5) {
            val y = t + j * h
            val ya = (y - 8f).toInt()
            val yb = (y - 3f).toInt()
            val yc = (y + 3f).toInt()
            val yd = (y + 8f).toInt()
            for (c in 0..7) {
                for (k in 0 until 6) {
                    val x = (l + c * w + (0.2f + 0.6f * (k + 0.5f) / 6f) * w).toInt()
                    var a = 0
                    for (yy in ya..yb) a += lumAt(f, x, yy)
                    var d = 0
                    for (yy in yc..yd) d += lumAt(f, x, yy)
                    sum += Math.abs(a / (yb - ya + 1f) - d / (yd - yc + 1f))
                    n++
                }
            }
        }
        return sum / n
    }

    /** Returns [centre, bestScore] using a coarse search then a 1px refinement (plateau centroid). */
    private fun search1D(p0: Float, range: Int, step: Int, ev: (Float) -> Float): FloatArray {
        var best = -1f
        var bp = p0
        var a = -range
        while (a <= range) {
            val s = ev(p0 + a)
            if (s > best) {
                best = s
                bp = p0 + a
            }
            a += step
        }
        val xs = FloatArray(9)
        val ss = FloatArray(9)
        var mx = -1f
        for (d in -4..4) {
            xs[d + 4] = bp + d
            ss[d + 4] = ev(bp + d)
            if (ss[d + 4] > mx) mx = ss[d + 4]
        }
        var sa = 0f
        var cnt = 0
        for (i in 0 until 9) {
            if (ss[i] >= 0.97f * mx) {
                sa += xs[i]
                cnt++
            }
        }
        return floatArrayOf(sa / cnt, mx)
    }

    private fun searchPair(p0: Float, q0: Float, range: Int, step: Int, ev: (Float, Float) -> Float): FloatArray {
        var best = -1f
        var bp = p0
        var bq = q0
        var a = -range
        while (a <= range) {
            var c = -range
            while (c <= range) {
                val s = ev(p0 + a, q0 + c)
                if (s > best) {
                    best = s
                    bp = p0 + a
                    bq = q0 + c
                }
                c += step
            }
            a += step
        }
        val pts = ArrayList<FloatArray>()
        var mx = -1f
        for (da in -4..4) {
            for (dc in -4..4) {
                val s = ev(bp + da, bq + dc)
                pts.add(floatArrayOf(bp + da, bq + dc, s))
                if (s > mx) mx = s
            }
        }
        var sa = 0f
        var sc = 0f
        var cnt = 0
        for (e in pts) {
            if (e[2] >= 0.97f * mx) {
                sa += e[0]
                sc += e[1]
                cnt++
            }
        }
        return floatArrayOf(sa / cnt, sc / cnt, mx)
    }

    /**
     * Finds the exact 8x8 grid from the checkerboard edges (squares are square).
     * Returns [left, top, right, bottom] or null if the picture does not look like a start position.
     */
    fun alignRect(f: Frame, l0: Float, t0: Float, r0: Float, b0: Float): FloatArray? {
        val lr = searchPair(l0, r0, 70, 5) { a, c -> scoreV(f, a, c, t0, b0) }
        if (lr[2] < 100f) return null
        var l = lr[0]
        var r = lr[1]
        val w = r - l
        val tt = search1D(t0, 70, 2) { tv -> scoreH(f, l, r, tv, tv + w) }
        if (tt[1] < 100f) return null
        val t = tt[0]
        val lr2 = searchPair(l, r, 10, 2) { a, c -> scoreV(f, a, c, t, t + (c - a)) }
        if (lr2[2] < 100f) return null
        l = lr2[0]
        r = lr2[1]
        return floatArrayOf(l, t, r, t + (r - l))
    }

    fun snapshot(r: Int, c: Int): IntArray = px[r * 8 + c].copyOf()

    fun diffTo(r: Int, c: Int, ref: IntArray): Float {
        val a = px[r * 8 + c]
        var sum = 0L
        var n = 0
        for (k in 0 until N) {
            val x = a[k]
            val y = ref[k]
            if (x < 0 || y < 0) continue
            sum += Math.abs(((x shr 16) and 255) - ((y shr 16) and 255)) +
                Math.abs(((x shr 8) and 255) - ((y shr 8) and 255)) +
                Math.abs((x and 255) - (y and 255))
            n++
        }
        return if (n == 0) 0f else sum / (3f * n)
    }

    /** Start-position check: returns the white/black luminance threshold, or null if not a start position. */
    fun startThreshold(): Float? {
        var top = 0f
        var tn = 0
        var bot = 0f
        var bn = 0
        for (r in 0..7) {
            for (c in 0..7) {
                val s = sqs[r * 8 + c]
                if (r in 2..5) {
                    if (s.occ) return null
                } else {
                    if (!s.occ) return null
                    if (r <= 1) {
                        top += s.lum
                        tn++
                    } else {
                        bot += s.lum
                        bn++
                    }
                }
            }
        }
        val tm = top / tn
        val bm = bot / bn
        if (Math.abs(tm - bm) < 50f) return null
        return (tm + bm) / 2f
    }

    /** Occupancy + colour grid in chess-square order: 0 empty, 1 white piece, -1 black piece. */
    fun occGrid(userWhite: Boolean, thr: Float, expected: IntArray?, ignore: IntArray?): IntArray {
        val g = IntArray(64)
        for (r in 0..7) {
            for (c in 0..7) {
                val sq = toSq(r, c, userWhite)
                if (ignore != null && expected != null && ignore.contains(sq)) {
                    g[sq] = expected[sq]
                    continue
                }
                val s = sqs[r * 8 + c]
                g[sq] = if (!s.occ) 0 else if (s.lum > thr) 1 else -1
            }
        }
        return g
    }

    /** Piece type index (0 P, 1 N, 2 B, 3 R, 4 Q, 5 K) of the piece on a square, or -1 if unsure. */
    fun classify(userWhite: Boolean, tpl: Templates, sq: Int): Int {
        val s = sqs[screenRow(sq, userWhite) * 8 + screenCol(sq, userWhite)]
        if (!s.occ) return -1
        var best = Int.MAX_VALUE
        var bt = -1
        for (t in 0..5) {
            for (tm in tpl.shapes[t]) {
                val d = shapeDist(s.mask, tm)
                if (d < best) {
                    best = d
                    bt = t
                }
            }
        }
        return if (best <= 0.3f * s.mass) bt else -1
    }

    fun occAt(r: Int, c: Int): Boolean = sqs[r * 8 + c].occ
    fun massAt(r: Int, c: Int): Int = sqs[r * 8 + c].mass
    fun maskAt(r: Int, c: Int): BooleanArray = sqs[r * 8 + c].mask

    private fun fillGaps(m: BooleanArray) {
        for (j in 0 until G) {
            var last = -1
            for (i in 0 until G) {
                if (m[j * G + i]) {
                    val gap = i - last - 1
                    if (last >= 0 && gap in 1..3) {
                        for (k in last + 1 until i) m[j * G + k] = true
                    }
                    last = i
                }
            }
        }
    }

    private fun shapeDist(a: BooleanArray, b: BooleanArray): Int {
        var best = Int.MAX_VALUE
        for (dy in -1..1) {
            for (dx in -1..1) {
                var d = 0
                for (y in 0 until G) {
                    val yy = y + dy
                    for (x in 0 until G) {
                        val xx = x + dx
                        val av = a[y * G + x]
                        val bv = if (xx in 0 until G && yy in 0 until G) b[yy * G + xx] else false
                        if (av != bv) d++
                    }
                }
                if (d < best) best = d
            }
        }
        return best
    }

    fun parse(userWhite: Boolean, tpl: Templates, prev: IntArray?, ignore: IntArray?): ParseResult {
        val board = IntArray(64)
        val unc = BooleanArray(64)
        var ok = true
        for (r in 0..7) {
            for (c in 0..7) {
                val s = sqs[r * 8 + c]
                val sq = toSq(r, c, userWhite)
                if (ignore != null && prev != null && ignore.contains(sq)) {
                    board[sq] = prev[sq]
                    continue
                }
                if (!s.occ) {
                    board[sq] = 0
                    continue
                }
                var best = Int.MAX_VALUE
                var bt = 0
                for (t in 0..5) {
                    for (tm in tpl.shapes[t]) {
                        val d = shapeDist(s.mask, tm)
                        if (d < best) {
                            best = d
                            bt = t
                        }
                    }
                }
                val white = s.lum > tpl.lumThr
                val code = (bt + 1) * (if (white) 1 else -1)
                if (best <= 0.22f * s.mass) {
                    board[sq] = code
                } else {
                    val p = if (prev != null) prev[sq] else 0
                    if (p != 0) {
                        board[sq] = p
                        unc[sq] = true
                    } else if (best <= 0.7f * s.mass) {
                        board[sq] = code
                        unc[sq] = true
                    } else {
                        board[sq] = code
                        ok = false
                    }
                }
            }
        }
        return ParseResult(board, unc, ok)
    }

    /** Learn piece shapes from the standard starting position currently on screen. */
    fun learn(userWhite: Boolean): Templates? {
        val lists = Array(6) { ArrayList<BooleanArray>() }
        val masses = Array(6) { ArrayList<Int>() }
        var wl = 0f
        var wn = 0
        var bl = 0f
        var bn = 0
        val init = initialBoard()
        for (r in 0..7) {
            for (c in 0..7) {
                val sq = toSq(r, c, userWhite)
                val s = sqs[r * 8 + c]
                val expected = init[sq]
                if (expected == 0) {
                    if (s.occ) return null
                } else {
                    if (!s.occ) return null
                    lists[Math.abs(expected) - 1].add(s.mask.copyOf())
                    masses[Math.abs(expected) - 1].add(s.mass)
                    if (expected > 0) {
                        wl += s.lum
                        wn++
                    } else {
                        bl += s.lum
                        bn++
                    }
                }
            }
        }
        if (wn == 0 || bn == 0) return null
        val wm = wl / wn
        val bm = bl / bn
        if (wm - bm < 50f) return null
        val shapes = Array<List<BooleanArray>>(6) { k ->
            // drop odd samples (glowing / half-drawn pieces) before choosing templates
            val sorted = masses[k].sorted()
            val med = sorted[sorted.size / 2]
            val good = ArrayList<BooleanArray>()
            for (i in lists[k].indices) {
                val m = masses[k][i]
                if (m >= 0.7f * med && m <= 1.45f * med) good.add(lists[k][i])
            }
            pick(if (good.isEmpty()) lists[k] else good, 5)
        }
        return Templates(shapes, (wm + bm) / 2f)
    }

    private fun pick(l: List<BooleanArray>, n: Int): List<BooleanArray> {
        if (l.size <= n) return ArrayList(l)
        val out = ArrayList<BooleanArray>()
        for (k in 0 until n) out.add(l[k * l.size / n])
        return out
    }
}
