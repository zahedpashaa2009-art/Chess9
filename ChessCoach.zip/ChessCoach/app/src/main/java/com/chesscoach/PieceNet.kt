package com.chesscoach

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Small neural network (MLP 1200 -> 192 -> 96 -> 13) that reads one board square:
 * class 0 = empty, 1..6 = white P N B R Q K, 7..12 = black P N B R Q K.
 * Input = 20x20 RGB picture of the square, values (v/255 - 0.5).
 */
class PieceNet(bytes: ByteArray) {
    private val dims: IntArray
    private val w = ArrayList<FloatArray>()
    private val b = ArrayList<FloatArray>()

    init {
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val n = bb.getInt()
        dims = IntArray(n + 1) { bb.getInt() }
        for (l in 0 until n) {
            val wa = FloatArray(dims[l] * dims[l + 1])
            for (i in wa.indices) wa[i] = bb.getFloat()
            val ba = FloatArray(dims[l + 1])
            for (i in ba.indices) ba[i] = bb.getFloat()
            w.add(wa)
            b.add(ba)
        }
    }

    fun inputSize(): Int = dims[0]

    fun forward(x: FloatArray): FloatArray {
        var cur = x
        val layers = w.size
        for (l in 0 until layers) {
            val inn = dims[l]
            val out = dims[l + 1]
            val nxt = FloatArray(out)
            val wl = w[l]
            val bl = b[l]
            for (o in 0 until out) nxt[o] = bl[o]
            for (i in 0 until inn) {
                val xi = cur[i]
                if (xi == 0f) continue
                val base = i * out
                for (o in 0 until out) nxt[o] += xi * wl[base + o]
            }
            if (l < layers - 1) {
                for (o in 0 until out) if (nxt[o] < 0f) nxt[o] = 0f
            }
            cur = nxt
        }
        var mx = cur[0]
        for (v in cur) if (v > mx) mx = v
        var sum = 0f
        for (i in cur.indices) {
            cur[i] = Math.exp((cur[i] - mx).toDouble()).toFloat()
            sum += cur[i]
        }
        for (i in cur.indices) cur[i] = cur[i] / sum
        return cur
    }
}
