package com.chesscoach;

import java.util.ArrayList;

/**
 * Minimal, self-contained chess rules (legal move generation) used to TRACK the game
 * from board occupancy only. Piece codes: 1 P, 2 N, 3 B, 4 R, 5 Q, 6 K; white positive, black negative.
 * Square index = rank * 8 + file (rank 0 = chess rank 1, file 0 = a).
 * Move = from | (to << 6) | (promo << 12), promo in {0, 2, 3, 4, 5}.
 */
public final class Rules {
    private Rules() {}

    public static final int WK = 1, WQ = 2, BK = 4, BQ = 8;

    public static final class Pos {
        public final int[] b = new int[64];
        public int side = 1; // 1 white to move, -1 black to move, 0 unknown
        public int castle = 0;
        public int ep = -1;

        public Pos copy() {
            Pos p = new Pos();
            System.arraycopy(b, 0, p.b, 0, 64);
            p.side = side;
            p.castle = castle;
            p.ep = ep;
            return p;
        }
    }

    public static final class Match {
        public int status; // 0 none, 1 unique, 2 ambiguous
        public Pos pos;
        public int[] moves;
    }

    private static final int[] BACK = {4, 2, 3, 5, 6, 3, 2, 4};

    public static Pos startPos() {
        Pos p = new Pos();
        for (int f = 0; f < 8; f++) {
            p.b[f] = BACK[f];
            p.b[8 + f] = 1;
            p.b[48 + f] = -1;
            p.b[56 + f] = -BACK[f];
        }
        p.side = 1;
        p.castle = WK | WQ | BK | BQ;
        p.ep = -1;
        return p;
    }

    public static int from(int m) { return m & 63; }
    public static int to(int m) { return (m >> 6) & 63; }
    public static int promo(int m) { return (m >> 12) & 7; }
    public static int mk(int f, int t, int promo) { return f | (t << 6) | (promo << 12); }

    public static String sqName(int sq) {
        return "" + (char) ('a' + (sq & 7)) + (char) ('1' + (sq >> 3));
    }

    public static String uci(int m) {
        String s = sqName(from(m)) + sqName(to(m));
        int pr = promo(m);
        if (pr != 0) s += "pnbrqk".charAt(pr - 1);
        return s;
    }

    /** True if square sq is attacked by pieces of colour `by` (+1 / -1). */
    public static boolean attacked(Pos p, int sq, int by) {
        int f = sq & 7, r = sq >> 3;
        int[] b = p.b;
        // pawns: a white pawn on (f+-1, r-1) attacks (f, r)
        int pr = r - by;
        if (pr >= 0 && pr < 8) {
            if (f > 0 && b[pr * 8 + f - 1] == by) return true;
            if (f < 7 && b[pr * 8 + f + 1] == by) return true;
        }
        // knights
        int[] kdf = {1, 2, 2, 1, -1, -2, -2, -1};
        int[] kdr = {2, 1, -1, -2, -2, -1, 1, 2};
        for (int i = 0; i < 8; i++) {
            int nf = f + kdf[i], nr = r + kdr[i];
            if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
            if (b[nr * 8 + nf] == 2 * by) return true;
        }
        // king
        for (int df = -1; df <= 1; df++) {
            for (int dr = -1; dr <= 1; dr++) {
                if (df == 0 && dr == 0) continue;
                int nf = f + df, nr = r + dr;
                if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
                if (b[nr * 8 + nf] == 6 * by) return true;
            }
        }
        // sliders
        int[] sdf = {1, -1, 0, 0, 1, 1, -1, -1};
        int[] sdr = {0, 0, 1, -1, 1, -1, 1, -1};
        for (int i = 0; i < 8; i++) {
            int nf = f + sdf[i], nr = r + sdr[i];
            while (nf >= 0 && nf <= 7 && nr >= 0 && nr <= 7) {
                int v = b[nr * 8 + nf];
                if (v != 0) {
                    boolean diag = i >= 4;
                    if (v == 5 * by) return true;
                    if (diag && v == 3 * by) return true;
                    if (!diag && v == 4 * by) return true;
                    break;
                }
                nf += sdf[i];
                nr += sdr[i];
            }
        }
        return false;
    }

    private static void addPawnMove(ArrayList<Integer> out, int f, int t, int side) {
        int rank = t >> 3;
        if (rank == 7 || rank == 0) {
            out.add(mk(f, t, 5));
            out.add(mk(f, t, 4));
            out.add(mk(f, t, 3));
            out.add(mk(f, t, 2));
        } else {
            out.add(mk(f, t, 0));
        }
    }

    private static void pseudo(Pos p, ArrayList<Integer> out) {
        int side = p.side;
        int[] b = p.b;
        for (int sq = 0; sq < 64; sq++) {
            int v = b[sq];
            if (v == 0 || (v > 0) != (side > 0)) continue;
            int t = Math.abs(v);
            int f = sq & 7, r = sq >> 3;
            if (t == 1) {
                int nr = r + side;
                if (nr < 0 || nr > 7) continue;
                int one = nr * 8 + f;
                if (b[one] == 0) {
                    addPawnMove(out, sq, one, side);
                    int startRank = side > 0 ? 1 : 6;
                    if (r == startRank) {
                        int two = (r + 2 * side) * 8 + f;
                        if (b[two] == 0) out.add(mk(sq, two, 0));
                    }
                }
                for (int df = -1; df <= 1; df += 2) {
                    int nf = f + df;
                    if (nf < 0 || nf > 7) continue;
                    int to = nr * 8 + nf;
                    if (b[to] != 0 && (b[to] > 0) != (side > 0)) addPawnMove(out, sq, to, side);
                    else if (to == p.ep && b[to] == 0) out.add(mk(sq, to, 0));
                }
            } else if (t == 2 || t == 6) {
                int[] dfs, drs;
                if (t == 2) {
                    dfs = new int[]{1, 2, 2, 1, -1, -2, -2, -1};
                    drs = new int[]{2, 1, -1, -2, -2, -1, 1, 2};
                } else {
                    dfs = new int[]{1, 1, 1, 0, 0, -1, -1, -1};
                    drs = new int[]{1, 0, -1, 1, -1, 1, 0, -1};
                }
                for (int i = 0; i < 8; i++) {
                    int nf = f + dfs[i], nr = r + drs[i];
                    if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
                    int to = nr * 8 + nf;
                    if (b[to] == 0 || (b[to] > 0) != (side > 0)) out.add(mk(sq, to, 0));
                }
                if (t == 6) {
                    if (side > 0 && sq == 4) {
                        if ((p.castle & WK) != 0 && b[7] == 4 && b[5] == 0 && b[6] == 0
                                && !attacked(p, 4, -1) && !attacked(p, 5, -1) && !attacked(p, 6, -1))
                            out.add(mk(4, 6, 0));
                        if ((p.castle & WQ) != 0 && b[0] == 4 && b[1] == 0 && b[2] == 0 && b[3] == 0
                                && !attacked(p, 4, -1) && !attacked(p, 3, -1) && !attacked(p, 2, -1))
                            out.add(mk(4, 2, 0));
                    } else if (side < 0 && sq == 60) {
                        if ((p.castle & BK) != 0 && b[63] == -4 && b[61] == 0 && b[62] == 0
                                && !attacked(p, 60, 1) && !attacked(p, 61, 1) && !attacked(p, 62, 1))
                            out.add(mk(60, 62, 0));
                        if ((p.castle & BQ) != 0 && b[56] == -4 && b[57] == 0 && b[58] == 0 && b[59] == 0
                                && !attacked(p, 60, 1) && !attacked(p, 59, 1) && !attacked(p, 58, 1))
                            out.add(mk(60, 58, 0));
                    }
                }
            } else {
                int[] sdf = {1, -1, 0, 0, 1, 1, -1, -1};
                int[] sdr = {0, 0, 1, -1, 1, -1, 1, -1};
                int from = (t == 4) ? 0 : (t == 3 ? 4 : 0);
                int to = (t == 4) ? 4 : 8;
                for (int i = from; i < to; i++) {
                    int nf = f + sdf[i], nr = r + sdr[i];
                    while (nf >= 0 && nf <= 7 && nr >= 0 && nr <= 7) {
                        int dst = nr * 8 + nf;
                        if (b[dst] == 0) {
                            out.add(mk(sq, dst, 0));
                        } else {
                            if ((b[dst] > 0) != (side > 0)) out.add(mk(sq, dst, 0));
                            break;
                        }
                        nf += sdf[i];
                        nr += sdr[i];
                    }
                }
            }
        }
    }

    /** Plays a (pseudo-legal) move and returns the new position. */
    public static Pos play(Pos p, int m) {
        Pos q = p.copy();
        int from = from(m), to = to(m), pr = promo(m);
        int side = p.side;
        int piece = q.b[from];
        int captured = q.b[to];
        q.ep = -1;
        int at = Math.abs(piece);
        if (at == 1) {
            if (to == p.ep && captured == 0 && (from & 7) != (to & 7)) {
                q.b[to - 8 * side] = 0;
            }
            if (Math.abs(to - from) == 16) q.ep = (from + to) / 2;
        }
        q.b[to] = pr != 0 ? side * pr : piece;
        q.b[from] = 0;
        if (at == 6 && Math.abs(to - from) == 2) {
            if (to > from) {
                q.b[from + 1] = q.b[from + 3];
                q.b[from + 3] = 0;
            } else {
                q.b[from - 1] = q.b[from - 4];
                q.b[from - 4] = 0;
            }
        }
        if (at == 6) q.castle &= (side > 0) ? ~(WK | WQ) : ~(BK | BQ);
        if (from == 0 || to == 0) q.castle &= ~WQ;
        if (from == 7 || to == 7) q.castle &= ~WK;
        if (from == 56 || to == 56) q.castle &= ~BQ;
        if (from == 63 || to == 63) q.castle &= ~BK;
        q.side = -side;
        return q;
    }

    public static int[] legalMoves(Pos p) {
        if (p.side == 0) return new int[0];
        ArrayList<Integer> ps = new ArrayList<>();
        pseudo(p, ps);
        int n = 0;
        int[] tmp = new int[ps.size()];
        for (int m : ps) {
            Pos q = play(p, m);
            int ksq = -1;
            int kv = 6 * p.side;
            for (int i = 0; i < 64; i++) if (q.b[i] == kv) { ksq = i; break; }
            if (ksq < 0) continue;
            if (!attacked(q, ksq, -p.side)) tmp[n++] = m;
        }
        int[] r = new int[n];
        System.arraycopy(tmp, 0, r, 0, n);
        return r;
    }

    public static int[] grid(Pos p) {
        int[] g = new int[64];
        for (int i = 0; i < 64; i++) g[i] = Integer.signum(p.b[i]);
        return g;
    }

    public static boolean sameGrid(Pos p, int[] g) {
        for (int i = 0; i < 64; i++) if (Integer.signum(p.b[i]) != g[i]) return false;
        return true;
    }

    private static boolean sameFromTo(int a, int b) {
        return (a & 4095) == (b & 4095);
    }

    private static Match search(Pos p, int[] g) {
        Match res = new Match();
        // depth 1
        int[] first = null;
        int firstMove = -1;
        boolean amb = false;
        for (int m : legalMoves(p)) {
            Pos q = play(p, m);
            if (sameGrid(q, g)) {
                if (first == null) {
                    first = new int[]{m};
                    firstMove = m;
                    res.pos = q;
                } else if (sameFromTo(firstMove, m)) {
                    if (promo(m) == 5) { first = new int[]{m}; firstMove = m; res.pos = q; }
                } else {
                    amb = true;
                }
            }
        }
        if (amb) { res.status = 2; return res; }
        if (first != null) { res.status = 1; res.moves = first; return res; }
        // depth 2 (my move + instant reply)
        int[] seq = null;
        int s1 = -1, s2 = -1;
        for (int m1 : legalMoves(p)) {
            Pos q1 = play(p, m1);
            for (int m2 : legalMoves(q1)) {
                Pos q2 = play(q1, m2);
                if (sameGrid(q2, g)) {
                    if (seq == null) {
                        seq = new int[]{m1, m2};
                        s1 = m1; s2 = m2;
                        res.pos = q2;
                    } else if (sameFromTo(s1, m1) && sameFromTo(s2, m2)) {
                        if (promo(m1) + promo(m2) > promo(s1) + promo(s2)) { seq = new int[]{m1, m2}; s1 = m1; s2 = m2; res.pos = q2; }
                    } else {
                        amb = true;
                    }
                }
            }
        }
        if (amb) { res.status = 2; return res; }
        if (seq != null) { res.status = 1; res.moves = seq; return res; }
        res.status = 0;
        return res;
    }

    /** Finds the move (or two moves) that turn p into the observed colour grid. */
    public static Match findMoves(Pos p, int[] g) {
        if (p.side != 0) return search(p, g);
        Pos w = p.copy(); w.side = 1;
        Pos k = p.copy(); k.side = -1;
        Match a = search(w, g);
        Match c = search(k, g);
        if (a.status == 1 && c.status == 0) return a;
        if (c.status == 1 && a.status == 0) return c;
        Match r = new Match();
        r.status = (a.status == 0 && c.status == 0) ? 0 : 2;
        return r;
    }

    public static int parseUci(Pos p, String s) {
        if (s == null || s.length() < 4) return -1;
        int f = (s.charAt(0) - 'a') + 8 * (s.charAt(1) - '1');
        int t = (s.charAt(2) - 'a') + 8 * (s.charAt(3) - '1');
        int pr = 0;
        if (s.length() > 4) pr = "pnbrqk".indexOf(Character.toLowerCase(s.charAt(4))) + 1;
        for (int m : legalMoves(p)) {
            if (from(m) == f && to(m) == t && promo(m) == pr) return m;
        }
        return -1;
    }

    public static String fen(Pos p) {
        StringBuilder sb = new StringBuilder();
        for (int rank = 7; rank >= 0; rank--) {
            int empty = 0;
            for (int file = 0; file < 8; file++) {
                int v = p.b[rank * 8 + file];
                if (v == 0) {
                    empty++;
                } else {
                    if (empty > 0) { sb.append(empty); empty = 0; }
                    char c = "pnbrqk".charAt(Math.abs(v) - 1);
                    sb.append(v > 0 ? Character.toUpperCase(c) : c);
                }
            }
            if (empty > 0) sb.append(empty);
            if (rank > 0) sb.append('/');
        }
        sb.append(p.side >= 0 ? " w " : " b ");
        String cs = "";
        if ((p.castle & WK) != 0) cs += "K";
        if ((p.castle & WQ) != 0) cs += "Q";
        if ((p.castle & BK) != 0) cs += "k";
        if ((p.castle & BQ) != 0) cs += "q";
        sb.append(cs.isEmpty() ? "-" : cs);
        sb.append(' ');
        if (p.ep >= 0) sb.append(sqName(p.ep)); else sb.append('-');
        sb.append(" 0 1");
        return sb.toString();
    }

    public static Pos fromFen(String fen) {
        String[] t = fen.split(" ");
        Pos p = new Pos();
        String[] rows = t[0].split("/");
        for (int i = 0; i < 8; i++) {
            int rank = 7 - i, file = 0;
            for (char c : rows[i].toCharArray()) {
                if (Character.isDigit(c)) { file += c - '0'; }
                else {
                    int type = "pnbrqk".indexOf(Character.toLowerCase(c)) + 1;
                    p.b[rank * 8 + file] = Character.isUpperCase(c) ? type : -type;
                    file++;
                }
            }
        }
        p.side = t[1].equals("w") ? 1 : -1;
        p.castle = 0;
        if (t[2].contains("K")) p.castle |= WK;
        if (t[2].contains("Q")) p.castle |= WQ;
        if (t[2].contains("k")) p.castle |= BK;
        if (t[2].contains("q")) p.castle |= BQ;
        p.ep = t[3].equals("-") ? -1 : (t[3].charAt(0) - 'a') + 8 * (t[3].charAt(1) - '1');
        return p;
    }
}
